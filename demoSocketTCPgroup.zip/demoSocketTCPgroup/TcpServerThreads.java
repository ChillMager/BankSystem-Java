package demoSocketTCPgroup;

import java.io.*;
import java.net.Socket;

public class TcpServerThreads extends Thread {
    private Socket socket;
    public TcpServerThreads(Socket socket) {
        this.socket = socket;
    }

     private void SendToAll(String msg) throws Exception {
         for (Socket onlineSocket : ServerTCP.OnlineSockets) {
             OutputStream os = onlineSocket.getOutputStream();
             DataOutputStream dos = new DataOutputStream(os);
             dos.writeUTF(msg);
             dos.flush();
         }
     }

    @Override
    public void run() {
        try {
            InputStream is = socket.getInputStream();
            DataInputStream dis = new DataInputStream(is);
            while (true){
                try {
                    String msg = dis.readUTF();
                    System.out.println(msg);
                    SendToAll(msg);

                } catch (IOException e) {
                    System.out.println("下线了  :"+socket.getRemoteSocketAddress());
                    ServerTCP.OnlineSockets.remove(socket);
                    dis.close();
                    socket.close();
                    break;
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }


}
