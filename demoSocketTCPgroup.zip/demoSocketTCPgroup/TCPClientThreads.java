package demoSocketTCPgroup;

import java.io.*;
import java.net.Socket;

public class TCPClientThreads extends Thread {
    private Socket socket;
    public TCPClientThreads(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            InputStream is = socket.getInputStream();
            DataInputStream dis = new DataInputStream(is);
            while (true) {
                try {
                    String msg = dis.readUTF();
                    System.out.println(msg);

                } catch (IOException e) {
                    System.out.println("下线了  :" + socket.getRemoteSocketAddress());

                    dis.close();
                    socket.close();
                    break;
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
