package demoSocketTCPgroup;


import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ServerTCP {
    public static List<Socket> OnlineSockets = new ArrayList<>();
    public static void main(String[] args) throws Exception {
        System.out.println("----------服务端启动----------");
        ServerSocket serverSocket = new ServerSocket(6666);

        while (true) {
            Socket socket = serverSocket.accept();
            OnlineSockets.add(socket);
            System.out.println("有人上线了: " + socket.getRemoteSocketAddress());

            new TcpServerThreads(socket).start();
        }


    }
}
