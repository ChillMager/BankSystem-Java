package BankSystem;

public class Test {
    public static void main(String[] args) {
        ATM atm = new ATM();
        atm.Menu();



    }
}
