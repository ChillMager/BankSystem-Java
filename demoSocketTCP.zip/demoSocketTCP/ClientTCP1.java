package demoSocketTCP;

import java.io.DataOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class ClientTCP1 {
    public static void main(String[] args) throws Exception {
        System.out.println("----------客户端启动----------");
        Socket socket = new Socket("127.0.0.1",6666);

        OutputStream os = socket.getOutputStream();
        DataOutputStream dos = new DataOutputStream(os);

        while (true) {
            Scanner sc =new Scanner(System.in);
            String message = sc.nextLine();

            if("exit".equals(message)){
                System.out.println("发送完毕！！！");
                dos.close();
                socket.close();
                break;
            }

            dos.writeUTF(message);
        }
        //dos.close();

    }
}
