package demoSocketTCP;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerTCP {
    public static void main(String[] args) throws Exception {
        System.out.println("----------服务端启动----------");
        ServerSocket serverSocket = new ServerSocket(6666);

        Socket socket = serverSocket.accept();

        InputStream is = socket.getInputStream();
        DataInputStream dis = new DataInputStream(is);

        while (true) {
            try {
                String receive = dis.readUTF();
                System.out.println(receive);
            } catch (IOException e) {
                System.out.println("用户退出了");
                dis.close();
                serverSocket.close();
                break;
            }
        }

        //dis.close();

    }
}
