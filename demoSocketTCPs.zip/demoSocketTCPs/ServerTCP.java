package demoSocketTCPs;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerTCP {
    public static void main(String[] args) throws Exception {
        System.out.println("----------服务端启动----------");
        ServerSocket serverSocket = new ServerSocket(6666);

        while (true) {
            Socket socket = serverSocket.accept();
            System.out.println("有人上线了: " + socket.getRemoteSocketAddress());

            new TcpServerThreads(socket).start();
        }


    }
}
