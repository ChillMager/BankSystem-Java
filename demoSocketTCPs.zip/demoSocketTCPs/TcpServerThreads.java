package demoSocketTCPs;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

public class TcpServerThreads extends Thread {
    private Socket socket;
    public TcpServerThreads(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            InputStream is = socket.getInputStream();
            DataInputStream dis = new DataInputStream(is);
            while (true){
                try {
                    String receiver = dis.readUTF();
                    System.out.println(receiver);
                } catch (IOException e) {
                    System.out.println("下线了  :"+socket.getRemoteSocketAddress());
                    break;
                }
            }
        } catch (IOException e) {

        }


    }
}
